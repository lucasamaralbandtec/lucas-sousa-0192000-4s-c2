package com.example.lucas_sousa_0192000_4s_c2

data class Cachorro (val raca:String, val precoMedio:Double, val indicadoCriancas:Boolean)