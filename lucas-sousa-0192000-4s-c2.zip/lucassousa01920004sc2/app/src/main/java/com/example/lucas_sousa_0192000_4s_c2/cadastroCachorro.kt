package com.example.lucas_sousa_0192000_4s_c2

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.view.isVisible
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.ThreadLocalRandom

class cadastroCachorro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_cachorro)

    }

    fun cadastrarCachorro(view: View)
    {
        val apiCachorro = ConexaoApiCachorros.criar()

        val svRecomendado:Switch = findViewById(R.id.sw_crianca)
        val recomendado:Boolean = svRecomendado.isChecked

        val etRaca:EditText = findViewById(R.id.et_raca)
        val raca = etRaca.text.toString()

        val etPrecoMedio:EditText = findViewById(R.id.et_precoMedio)
        val precoMedio = etPrecoMedio.text.toString().toDouble()

        val cachorro = Cachorro(raca, precoMedio, recomendado)

        apiCachorro.post(cachorro).enqueue(object : Callback<Cachorro> {
            override fun onResponse(call: Call<Cachorro>, response: Response<Cachorro>) {
                if (response.code() == 201)
                {
                    val ivImagem:ImageView = findViewById(R.id.iv_cachorro)
                    ivImagem.visibility = View.VISIBLE;
                    Toast.makeText(baseContext, "Cachorro cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                }
                else
                    {
                    Toast.makeText(baseContext, "Falha ao cadastrar cachorro: ${response.errorBody()!!}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Cachorro>, t: Throwable) {
                Toast.makeText(baseContext, "Erro na chamada: ${t.message!!}", Toast.LENGTH_SHORT).show()
            }
        })

    }
}