package com.example.lucas_sousa_0192000_4s_c2

import retrofit2.Call
import retrofit2.http.*

interface ApiCachorro {

    @GET("cachorros")
    fun get(): Call<List<Cachorro>>

    @POST("cachorros")
    fun post(@Body novoFilme:Cachorro): Call<Cachorro>
}