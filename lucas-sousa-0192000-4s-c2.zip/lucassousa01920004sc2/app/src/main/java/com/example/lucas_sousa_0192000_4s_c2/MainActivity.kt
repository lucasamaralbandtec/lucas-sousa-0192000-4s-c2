package com.example.lucas_sousa_0192000_4s_c2

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.reflect.typeOf

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun irTelaCadastro(view: View)
    {
        val  telacadastroCachorro = Intent(this, cadastroCachorro::class.java)
        startActivity(telacadastroCachorro)
    }

    fun listarCachorro(view: View)
    {
        val layoutLista: LinearLayout = findViewById(R.id.layout_lista)
        val tvCachorroNaoIndicado:TextView = findViewById(R.id.tv_cachorroNaoIndicado)
        val tvCachorroIndicado:TextView = findViewById(R.id.tv_cachorroIndicado)
        val tvTotalCachorro:TextView = findViewById(R.id.tv_totalCachorros)

        val apiCachorro = ConexaoApiCachorros.criar()

        var totalIndicados:Int = 0;
        var totalNaoIndicados:Int = 0;
        var totalCachorros:Int = 0;

        apiCachorro.get().enqueue(object : Callback<List<Cachorro>> {

            override fun onResponse(call: Call<List<Cachorro>>, response: Response<List<Cachorro>>) {

                response.body()?.forEach {

                        val tvCachorrro = TextView(baseContext)
                        tvCachorrro.text = "Raça: ${it.raca} - Preço Médio: ${it.precoMedio.toString()} - Indicado para Crianças: ${it.indicadoCriancas.toString()}\n"
                        tvCachorrro.setTextColor(Color.parseColor("#9911AA"))

                        if (it.indicadoCriancas) totalIndicados++; else totalNaoIndicados++;

                        layoutLista.addView(tvCachorrro)
                }

                totalCachorros = totalIndicados + totalNaoIndicados

                tvCachorroIndicado.text = "Cachorros indicados para crianças: " + totalIndicados.toString();
                tvCachorroNaoIndicado.text = "Cachorros não indicados para crianças: " + totalNaoIndicados.toString();
                tvTotalCachorro.text =  "Total de Cachorros: " + totalCachorros.toString() +"\n";
            }

            override fun onFailure(call: Call<List<Cachorro>>, t: Throwable) {
                Toast.makeText(baseContext, "Erro na chamada: ${t.message!!}", Toast.LENGTH_SHORT).show()
            }

        })

    }

    fun String.intOrString() = try {
        toInt()
    } catch(e: NumberFormatException) {
        this
    }
}